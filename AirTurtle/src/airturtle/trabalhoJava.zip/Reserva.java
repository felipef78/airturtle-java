/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ronnie
 */
public class Reserva {

    private int fileiraAssento;
    private int numeroAssento;
    private boolean isExecutiva;
    private String cpfCliente;
    private boolean ativo;
    private int id;
    private Voo voo;

    public Reserva() {
    }

    public Reserva(int fileiraAssento, int numeroAssento, boolean isExecutiva, Voo voo, String cpfCliente, int id) {
        this.fileiraAssento = fileiraAssento;
        this.numeroAssento = numeroAssento;
        this.isExecutiva = isExecutiva;
        this.voo = voo;
        this.cpfCliente = cpfCliente;
        this.id = id;
        this.ativo = true;
    }

    public List<String> consultarReserva(Reserva reserva) throws NumberFormatException {
        List<String> lis = new ArrayList<>();
        
       
        //lis.add(String.valueOf(reserva.getVoo().getCodigoIdentificador()));
        lis.add(String.valueOf(reserva.getFileiraAssento()));
        lis.add(String.valueOf(reserva.getNumeroAssento()));
        lis.add(String.valueOf(reserva.isIsExecutiva()));
         lis.add(reserva.getCpfCliente());
        lis.add(String.valueOf(reserva.isAtivo()));
        lis.add(String.valueOf(reserva.getId()));
        return lis;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFileiraAssento() {
        return fileiraAssento;
    }

    public int getNumeroAssento() {
        return numeroAssento;
    }

    public Voo getVoo() {
        return voo;
    }

    public String getCpfCliente() {
        return cpfCliente;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public boolean isIsExecutiva() {
        return isExecutiva;
    }

    public void setFileiraAssento(char fileiraAssento) {
        this.fileiraAssento = fileiraAssento;
    }

    public void setIsExecutiva(boolean isExecutiva) {
        this.isExecutiva = isExecutiva;
    }

    public void setNumeroAssento(int numeroAssento) {
        this.numeroAssento = numeroAssento;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public void setCpfCliente(String cpfCliente) {
        this.cpfCliente = cpfCliente;
    }

    public void setVoo(Voo voo) {
        this.voo = voo;
    }
    
    

    public void setCampos(List<Object> campos) {
        setFileiraAssento(campos.get(0).toString().charAt(0));
        setNumeroAssento(Integer.valueOf(campos.get(1).toString()));
        setIsExecutiva((boolean)campos.get(2));
        setCpfCliente(campos.get(3).toString());
        setAtivo((boolean)campos.get(4));
        setId(Integer.valueOf(campos.get(5).toString()));       
        setVoo((Voo)campos.get(6));
    }
}
