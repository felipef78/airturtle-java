/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author ronnie
 */
class Disponibilidade {

    private Date hora;
    private Destino destino;

    public Disponibilidade() {
        this.hora = null;
        this.destino = null;
    }

    public boolean calculaDisponibilidade(Date horaVoo) {
        if (hora == null && destino == null) {
            return true;
        } else {

            double idaVoltaMinutos = (2 * (destino.getDistanciaBase() / 1000)) * 60 * 60 * 1000;
            long milisegundos = horaVoo.getTime() - (long) (hora.getTime() + idaVoltaMinutos);
            long segundos = milisegundos / 1000;
            long minutos = segundos / 60;
            long horas = minutos / 60;

//            double horaEmMinutos = this.hora.getHours() * 100 + this.hora.getMinutes();
//            double soma = i daVoltaMinutos + horaEmMinutos;
//            double resultado = (horaVoo.getHours() * 100 + horaVoo.getMinutes()) - soma;
//            long result = ((hora.getTime() / 60) / 60) + 2;
            if (horas >= 2) {
                return true;
            } else {
                return false;
            }
        }
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public void setDestino(Destino destino) {
        this.destino = destino;
    }
}

public class Aeronave {

    private String prefixoIdentificador;
    private String modelo;
    private int autonomia;
    private int numTotalFileiras;
    private int numAssentosPorFileiras;
    private int numFileirasExecutiva;
    private int numFileirasEconomica;
    List<Voo> voos = new ArrayList<>();
    private Disponibilidade disponibilidade;
    private boolean[][] mapaDeAssentos;

    public Aeronave() {
    }

    public boolean verificaDisponibilidade(Date hora) {
        return disponibilidade.calculaDisponibilidade(hora);
    }

    public Disponibilidade getDisponibilidade() {
        return disponibilidade;
    }

    public Aeronave(String prefixoIdentificador, String modelo, int autonomia, int numTotalFileiras, int numAssentosPorFileiras, int numFileirasExecutiva, int numFileirasEconomica) {
        this.prefixoIdentificador = prefixoIdentificador;
        this.modelo = modelo;
        this.autonomia = autonomia;
        this.numTotalFileiras = numTotalFileiras;
        this.numAssentosPorFileiras = numAssentosPorFileiras;
        this.numFileirasExecutiva = numFileirasExecutiva;
        this.numFileirasEconomica = numFileirasEconomica;

        this.disponibilidade = new Disponibilidade();
        mapaDeAssentos = new boolean[numTotalFileiras][numAssentosPorFileiras];
        for (int i = 0; i < numTotalFileiras; i++) {
            for (int j = 0; j < numAssentosPorFileiras; j++) {
                mapaDeAssentos[i][j] = true;
            }
        }
    }
    
    public List<String> consultarAeronave(Aeronave aero) {
        List<String> list = new ArrayList<>();
        list.add(aero.getPrefixoIdentificador());
        list.add(aero.getModelo());
        list.add(String.valueOf(aero.getAutonomia()));
        list.add(String.valueOf(aero.getNumAssentosPorFileiras()));
        list.add(String.valueOf(aero.getNumFileirasEconomica()));
        list.add(String.valueOf(aero.getNumFileirasExecutiva()));
        list.add(String.valueOf(aero.getNumTotalFileiras()));
        return list;
    }

    public boolean[][] getMapaAssentos() {
        return mapaDeAssentos;
    }

    public int getAutonomia() {
        return autonomia;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNumAssentosPorFileiras() {
        return numAssentosPorFileiras;
    }

    public int getNumFileirasEconomica() {
        return numFileirasEconomica;
    }

    public int getNumFileirasExecutiva() {
        return numFileirasExecutiva;
    }

    public int getNumTotalFileiras() {
        return numTotalFileiras;
    }

    public String getPrefixoIdentificador() {
        return prefixoIdentificador;
    }

    public void setAutonomia(int autonomia) {
        this.autonomia = autonomia;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setNumAssentosPorFileiras(int numAssentosPorFileiras) {
        this.numAssentosPorFileiras = numAssentosPorFileiras;
    }

    public void setNumFileirasEconomica(int numFileirasEconomica) {
        this.numFileirasEconomica = numFileirasEconomica;
    }

    public void setNumFileirasExecutiva(int numFileirasExecutiva) {
        this.numFileirasExecutiva = numFileirasExecutiva;
    }

    public void setNumTotalFileiras(int numTotalFileiras) {
        this.numTotalFileiras = numTotalFileiras;
    }

    public void setPrefixoIdentificador(String prefixoIdentificador) {
        this.prefixoIdentificador = prefixoIdentificador;
    }
    
    public void setCampos(List<Object> campos) throws NumberFormatException {
        this.setPrefixoIdentificador(campos.get(0).toString());
        this.setModelo(campos.get(1).toString());
        this.setAutonomia(Integer.parseInt(campos.get(2).toString()));
        this.setNumTotalFileiras(Integer.parseInt(campos.get(3).toString()));
        this.setNumAssentosPorFileiras(Integer.parseInt(campos.get(4).toString()));
        this.setNumFileirasExecutiva(Integer.parseInt(campos.get(5).toString()));
        this.setNumFileirasEconomica(Integer.parseInt(campos.get(6).toString()));
    }
}
