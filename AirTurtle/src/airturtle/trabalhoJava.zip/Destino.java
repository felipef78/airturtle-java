/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ronnie
 */
public class Destino {

    private String nomeCidade;
    private String nomeAeroporto;
    private int fusoHorario;
    private double distanciaBase;
    private String pais;
    private int id;
    private Endereco endereco;

    public Destino() {
    }

    public Destino(int id, String nomeCidade, String nomeAeroporto, int fusoHorario, double distanciaBase, Endereco endereco, String pais) {
        this.nomeCidade = nomeCidade;
        this.nomeAeroporto = nomeAeroporto;
        this.fusoHorario = fusoHorario;
        this.distanciaBase = distanciaBase;
        this.endereco = endereco;
        this.pais = pais;
        this.id = id;
    }

    public List<String> consultarDestino(Destino des)  throws NumberFormatException, ArrayIndexOutOfBoundsException {
        List<String> lis = new ArrayList<>();
        lis.add(des.getNomeCidade());
        
        lis.add(des.getNomeAeroporto());
        lis.add(String.valueOf(des.getFusoHorario()));
        lis.add(String.valueOf(des.getDistanciaBase()));
        lis.add(des.getPais());
        lis.add(String.valueOf(des.getId()));
        //lis.add(String.valueOf(des.getEnderecoAeroporto()));
        return lis;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void setCampos(List<Object> campos) {
        
        //Lembrar de colocar tratamento de erros aqui!
        setNomeCidade(campos.get(0).toString());
        setNomeAeroporto(campos.get(1).toString());
        setFusoHorario(Integer.parseInt(campos.get(2).toString()));
        setDistanciaBase(Double.parseDouble(campos.get(3).toString()));
        setPais(campos.get(4).toString());
        setId(Integer.parseInt(campos.get(5).toString()));
//        setEndereco((Endereco)campos.get(6));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeCidade() {
        return this.nomeCidade;
    }

    public String getNomeAeroporto() {
        return this.nomeAeroporto;
    }

    public int getFusoHorario() {
        return this.fusoHorario;
    }

    public double getDistanciaBase() {
        return this.distanciaBase;
    }

    public Endereco getEnderecoAeroporto() {
        return this.endereco;
    }

    public String getPais() {
        return this.pais;
    }

    public Endereco getEndereco() {
        return this.endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public void setDistanciaBase(double distanciaBase) {
        this.distanciaBase = distanciaBase;
    }

    public void setFusoHorario(int fusoHorario) {
        this.fusoHorario = fusoHorario;
    }

    public void setNomeAeroporto(String nomeAeroporto) {
        this.nomeAeroporto = nomeAeroporto;
    }

    public void setNomeCidade(String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }
}
