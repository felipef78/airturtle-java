/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author ronnie
 */
public class Voo {

    private int codigoIdentificador;
    private Date data;
    private double valorPassagemEconomica;
    private double valorPassagemExecutiva;
    private int numeroLugaresVagos;
    private int numeroLugaresOcupados;
    private boolean[][] mapaDeOcupacao;
    private Destino destino;
    private Aeronave aeronave;
    List<Reserva> reservas = new ArrayList<>();

    public Destino getDestino() {
        return destino;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public Voo() {
    }

    public Voo(int codigoIdentificador, Date data, double valorPassagemEconomica, double valorPassagemExecutiva, int numeroLugaresVagos, int numeroLugaresOcupados, Destino destino, Aeronave aeronave) {
        if (aeronave.verificaDisponibilidade(data) && aeronave.getAutonomia() >= destino.getDistanciaBase()) {
            this.aeronave = aeronave;
            this.codigoIdentificador = codigoIdentificador;
            this.data = data;
            //this.hora = hora;
            this.valorPassagemEconomica = valorPassagemEconomica;
            this.valorPassagemExecutiva = valorPassagemExecutiva;
            this.numeroLugaresVagos = numeroLugaresVagos;
            this.numeroLugaresOcupados = numeroLugaresOcupados;
            boolean[][] mapa = aeronave.getMapaAssentos();
            for (int i = 0; i < aeronave.getNumTotalFileiras(); i++) {
                for (int j = 0; j < aeronave.getNumAssentosPorFileiras(); j++) {
                    mapa[i][j] = false;
                }
            }
            aeronave.getDisponibilidade().setDestino(destino);
            aeronave.getDisponibilidade().setHora(data);
            this.mapaDeOcupacao = mapa;
            this.destino = destino;
        } else {
            System.out.println("Erro! Aeronave indisponivel, tente mais tarde. Ou destino fora de alcance para esta aeronave.");
        }
    }
    
    public List<String> consultarVoo(Voo voo) throws NumberFormatException, NullPointerException {
        List<String> lis = new ArrayList<>();
        lis.add(String.valueOf(getCodigoIdentificador()));
        //lis.add(voo.destino.getNomeCidade() + ", " + voo.destino.getPais());
        //lis.add(String.valueOf(voo.getData()));
        
        lis.add(String.valueOf(voo.getValorPassagemEconomica()));
        lis.add(String.valueOf(voo.getValorPassagemExecutiva()));
        lis.add(String.valueOf(voo.getNumeroLugaresVagos()));
        lis.add(String.valueOf(voo.getNumeroLugaresOcupados()));
        //lis.add(voo.aeronave.getModelo());
        
        return lis;
    }

    public int getCodigoIdentificador() {
        return codigoIdentificador;
    }

    public boolean[][] getMapaDeOcupacao() {
        return mapaDeOcupacao;
    }

    public Date getData() {
        return data;
    }

    public Aeronave getAeronave() {
        return aeronave;
    }

    public int getNumeroLugaresOcupados() {
        return numeroLugaresOcupados;
    }

    public int getNumeroLugaresVagos() {
        return numeroLugaresVagos;
    }

    public double getValorPassagemEconomica() {
        return valorPassagemEconomica;
    }

    public double getValorPassagemExecutiva() {
        return valorPassagemExecutiva;
    }

    public void setCodigoIdentificador(int codigoIdentificador) {
        this.codigoIdentificador = codigoIdentificador;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setMapaDeOcupacao(boolean[][] mapaDeOcupacao) {
        this.mapaDeOcupacao = mapaDeOcupacao;
    }

    public void setNumeroLugaresOcupados(int numeroLugaresOcupados) {
        this.numeroLugaresOcupados = numeroLugaresOcupados;
    }

    public void setNumeroLugaresVagos(int numeroLugaresVagos) {
        this.numeroLugaresVagos = numeroLugaresVagos;
    }

    public void setValorPassagemEconomica(double valorPassagemEconomica) {
        this.valorPassagemEconomica = valorPassagemEconomica;
    }

    public void setValorPassagemExecutiva(double valorPassagemExecutiva) {
        this.valorPassagemExecutiva = valorPassagemExecutiva;
    }

    public void setReserva(Reserva reservas) {
        this.reservas.add(reservas);
    }

    public void setAeronave(Aeronave aeronave) {
        this.aeronave = aeronave;
    }
    
    
    public void setCampos(List<Object> campos){
        this.setCodigoIdentificador(Integer.parseInt(campos.get(0).toString()));
        this.setValorPassagemEconomica(Double.parseDouble(campos.get(1).toString()));
        this.setValorPassagemExecutiva(Double.parseDouble(campos.get(2).toString()));
        this.setNumeroLugaresVagos(Integer.parseInt(campos.get(3).toString()));
        this.setNumeroLugaresOcupados(Integer.parseInt(campos.get(4).toString()));
        this.setAeronave((Aeronave)campos.get(5));
    }
}
