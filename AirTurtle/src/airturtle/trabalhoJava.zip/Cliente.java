/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ronnie
 */
public class Cliente extends Pessoa {

    private boolean isClienteFidelidade;
    private String numeroFidelidade;
    List<Reserva> reservas = new ArrayList<>();

    public Cliente() {
    }

    public Cliente(boolean isClienteFidelidade, String numeroFidelidade, String nome, String cpf, String email, String telefone, String celular, Endereco endereco) {
        super(nome, cpf, email, telefone, celular, endereco);
        this.isClienteFidelidade = isClienteFidelidade;
        this.numeroFidelidade = numeroFidelidade;
    }

    public List<String> consultarCliente(Cliente cli) throws NumberFormatException {
        List<String> lis = new ArrayList<>();
                lis.add(String.valueOf(cli.getIsClienteFidelidade()));
        //if (cli.getIsClienteFidelidade()) {
        lis.add(cli.getNumeroFidelidade());
        //}
        lis.add(cli.getNome());
        lis.add(cli.getCpf());
                lis.add(cli.getEmail());
        lis.add(cli.getTelefone());
        lis.add(cli.getCelular());

        //lis.add(String.valueOf(cli.getEndereco()));

        return lis;
    }
    

    public List<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(Reserva reservas) {
        this.reservas.add(reservas);
    }
    
    @Override
    public void setCampos(List<Object> campos){
        setIsClienteFidelidade(Boolean.valueOf(campos.get(0).toString()));
        setNumeroFidelidade(campos.get(1).toString());
    }

    public String getNumeroFidelidade() {
        return numeroFidelidade;
    }

    public boolean getIsClienteFidelidade() {
        return isClienteFidelidade;
    }

    public void setIsClienteFidelidade(boolean isClienteFidelidade) {
        this.isClienteFidelidade = isClienteFidelidade;
    }

    public void setNumeroFidelidade(String numeroFidelidade) {
        this.numeroFidelidade = numeroFidelidade;
    }

    void setPessoa(Pessoa objeto) {
        Pessoa pessoa = objeto;
        this.setNome(pessoa.getNome());
        this.setCelular(pessoa.getCelular());
        this.setCpf(pessoa.getCpf());
        this.setEmail(pessoa.getEmail());
        //this.setEndereco(pessoa.getEndereco());
        this.setTelefone(pessoa.getTelefone());
    }
}
