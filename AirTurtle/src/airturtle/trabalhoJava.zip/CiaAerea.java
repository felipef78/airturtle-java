/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package airturtle;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author ronnie
 */
public class CiaAerea {

    List<Reserva> reservas = new ArrayList<>();
    List<Aeronave> aeronaves = new ArrayList<>();
    List<Voo> voos = new ArrayList<>();
    List<Destino> destinos = new ArrayList<>();
    List<Cliente> clientes = new ArrayList<>();

    public CiaAerea() {
    }

    public void cadastrarDestino(int id, String nomeCidade, String nomeAeroporto, int fusoHorario, double distanciaBase, Endereco endereco, String pais) {
        Destino destino = new Destino(id, nomeCidade, nomeAeroporto, fusoHorario, distanciaBase, endereco, pais);
        destinos.add(destino);
    }

    public void removerDestino(int index) {
        for (int i = 0; i < voos.size(); i++) {
            Voo voo = voos.get(i);
            Destino des = voo.getDestino();
            if (des.getId() == voos.get(index).getDestino().getId()) {
                this.removerVoo(i);
            }
        }
        destinos.remove(index);
    }

    //TODO: alterar destino
    public void alterarDestino(int id, int escolha, Object valor) {
        for (Destino destino : destinos) {
            if (id == destino.getId()) {
                System.out.println("1 nomeCidade, 2 nomeAeroporto, 3 fusoHorario, 4 distanciaBase");
                System.out.println("5 endereço, 6 pais");
                switch (escolha) {
                    case 1:
                        destino.setNomeCidade((String) valor);
                        break;
                    case 2:
                        destino.setNomeAeroporto((String) valor);
                        break;
                    case 3:
                        destino.setFusoHorario(Integer.parseInt((String) valor));
                        break;
                    case 4:
                        destino.setDistanciaBase(Double.parseDouble((String) valor));
                        break;
                    case 5:
                        destino.setEndereco((Endereco) valor);
                        break;
                    case 6:
                        destino.setPais((String) valor);
                        break;
                }
            }
        }
    }

    public void cadastrarAeronave(String prefixoIdentificador, String modelo, int autonomia, int numTotalFileiras, int numAssentosPorFileiras, int numFileirasExecutiva, int numFileirasEconomica) {
        Aeronave aeronave = new Aeronave(prefixoIdentificador, modelo, autonomia, numTotalFileiras, numAssentosPorFileiras, numFileirasExecutiva, numFileirasEconomica);
        aeronaves.add(aeronave);
    }

    public void removerAeronave(int index) {
        for (int i = 0; i < voos.size(); i++) {
            Voo voo = voos.get(i);
            Aeronave aero = voo.getAeronave();
            if (aero.getPrefixoIdentificador().equals(aeronaves.get(index).getPrefixoIdentificador())) {
                this.removerVoo(i);
            }
        }
        aeronaves.remove(index);
    }

    //Novo jeito de alterar coisas, mandando o numero do campo de escolha já como parâmetro da função alterar.
    //TODO: averiguar para determinar se este modo é melhor que o outro de digitar a escolha.
    //lembrando que aparentemente o programa terá que ser chamado pela pain apenas
    //então talvez devessemos mandar o numero do campo e o valor que queremos para ele como parâmetro
    public void alterarAeronave(int prefixoIdentificador, int escolha, String valor) {
        for (Aeronave aeronave : aeronaves) {
            if (prefixoIdentificador == Integer.parseInt(aeronave.getPrefixoIdentificador())) {
                System.out.println("Você deseja alterar qual campo?");
                System.out.println("1 modelo, 2 autonomia, 3 numTotalFileiras, 4 numAssentosPorFileiras");
                System.out.println("5 numFileirasExecutiva, 6 numFileirasEconomica");

                switch (escolha) {
                    case 1:
                        System.out.println("Valor atual: " + aeronave.getModelo());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setModelo(valor);
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 2:
                        System.out.println("Valor atual: " + aeronave.getAutonomia());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setAutonomia(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 3:
                        System.out.println("Valor atual: " + aeronave.getNumTotalFileiras());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setNumTotalFileiras(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 4:
                        System.out.println("Valor atual: " + aeronave.getNumAssentosPorFileiras());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setNumAssentosPorFileiras(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 5:
                        System.out.println("Valor atual: " + aeronave.getNumFileirasExecutiva());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setNumFileirasExecutiva(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 6:
                        System.out.println("Valor atual: " + aeronave.getNumFileirasEconomica());
                        System.out.println("Digite um novo valor para o campo: ");
                        aeronave.setNumFileirasEconomica(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                }
            }
        }
    }

    public void cadastrarVoo(int codigoIdentificador, Date data, double valorPassagemEconomica, double valorPassagemExecutiva, int numeroLugaresVagos, int numeroLugaresOcupados, Destino destino, Aeronave aeronave) {
        Voo voo = new Voo(codigoIdentificador, data, valorPassagemEconomica, valorPassagemExecutiva, numeroLugaresVagos, numeroLugaresOcupados, destino, aeronave);
        voos.add(voo);
    }

    public void removerVoo(int index) {
        for (int i = 0; i < voos.get(index).getReservas().size(); i++) {
            this.removerReserva(i);
        }
        voos.remove(index);
    }

    public void alterarVoo(int codigoIdentificador, int escolha, String valor) throws ParseException {
        boolean sim;
        //do {
        for (Voo voo : voos) {
            if (voo.getCodigoIdentificador() == codigoIdentificador) {
                System.out.println("Você deseja alterar qual campo?");
                System.out.println("1 data, 3 valorPassagemEconomica, 4 valorPassagemExecutiva");
                System.out.println("5 numeroLugaresVagos, 6 numeroLugaresOcupados");
                SimpleDateFormat simpDF;

                switch (escolha) {
                    case 1:
                        System.out.println("Valor atual: " + voo.getData());
                        System.out.println("Digite um novo valor para o campo: ");
                        simpDF = new SimpleDateFormat("%d/%m/%y");
                        voo.setData(simpDF.parse(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 3:
                        System.out.println("Valor atual: " + voo.getValorPassagemEconomica());
                        System.out.println("Digite um novo valor para o campo: ");
                        voo.setValorPassagemEconomica(Double.parseDouble(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 4:
                        System.out.println("Valor atual: " + voo.getValorPassagemExecutiva());
                        System.out.println("Digite um novo valor para o campo: ");
                        voo.setValorPassagemExecutiva(Double.parseDouble(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 5:
                        System.out.println("Valor atual: " + voo.getNumeroLugaresVagos());
                        voo.setNumeroLugaresVagos(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                    case 6:
                        System.out.println("Valor atual: " + voo.getNumeroLugaresOcupados());
                        System.out.println("Digite um novo valor para o campo: ");
                        voo.setNumeroLugaresOcupados(Integer.parseInt(valor));
                        System.out.println("Campo alterado com sucesso!");
                        break;
                }
                break;
            }
        }
        /*System.out.println("Deseja alterar outro campo? s/n");
         Scanner scan = new Scanner(System.in);

         if (scan.next().equals("s")) {
         sim = true;
         } else {
         sim = false;
         }
         } while (sim);*/
    }

    public void cadastrarCliente(boolean isClienteFidelidade, String numeroFidelidade, String nome, String cpf, String email, String telefone, String celular, Endereco endereco) {
        Cliente cliente = new Cliente(isClienteFidelidade, numeroFidelidade, nome, cpf, email, telefone, celular, endereco);
        clientes.add(cliente);
    }

    public void removerCliente(int index) {
        for (int i = 0; i < clientes.get(index).getReservas().size(); i++) {
            this.removerReserva(i);
        }
        clientes.remove(index);
    }

    public void alterarCliente(String cpfCliente, int escolha, Object valor) {
        boolean sim;
        //do {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpfCliente)) {
                System.out.println("Você deseja alterar qual campo?");
                System.out.println("1 Fidelidade, 2 Numero Fidelidade, 3 Nome, 4 CPF");
                System.out.println("5 E-mail, 6 Telefone, 7 Celular, 8 Endereço");

                switch (escolha) {
                    case 1:
                        if (cliente.getIsClienteFidelidade()) {
                            System.out.println("Fidelidade atual: Sim");
                        } else {
                            System.out.println("Fidelidade atual: Nao");
                        }
                        cliente.setIsClienteFidelidade(Boolean.parseBoolean((String) valor));
                        break;
                    case 2:
                        cliente.setNumeroFidelidade((String) valor);
                        break;
                    case 3:
                        cliente.setNome((String) valor);
                        break;
                    case 4:
                        cliente.setCpf((String) valor);
                        break;
                    case 5:
                        cliente.setEmail((String) valor);
                        break;
                    case 6:
                        cliente.setTelefone((String) valor);
                        break;
                    case 7:
                        cliente.setCelular((String) valor);
                        break;
                    case 8:
                        cliente.setEndereco((Endereco) valor);
                        break;
                }
                break;
            }
        }
        /*   System.out.println("Deseja alterar outro campo? s/n");
         Scanner scan = new Scanner(System.in);

         if (scan.next().equals("s")) {
         sim = true;
         } else {
         sim = false;
         }
         } while (sim);*/

    }

    public boolean efetuarReserva(int codigoVoo, int fileira, int assento, String cpfCliente, int id) {
        //TODO: verificar assento vago e isExecutivo
        for (Voo voo : voos) {
            if (codigoVoo == voo.getCodigoIdentificador()) {
                if (voo.getMapaDeOcupacao()[fileira][assento] == false) {
                    boolean[][] mapa = voo.getMapaDeOcupacao();
                    mapa[fileira][assento] = true;
                    voo.setMapaDeOcupacao(mapa);
                    if (fileira < voo.getAeronave().getNumFileirasExecutiva()) {
                        Reserva reserva = new Reserva(fileira, assento, true, voo, cpfCliente, id);
                        reservas.add(reserva);
                        voo.setReserva(reserva);
                        for (Cliente cli : clientes) {
                            if (cli.getCpf().equals(cpfCliente)) {
                                cli.setReservas(reserva);
                            }
                        }
                        return true;
                    } else {
                        Reserva reserva = new Reserva(fileira, assento, false, voo, cpfCliente, id);
                        reservas.add(reserva);
                        voo.setReserva(reserva);
                        for (Cliente cli : clientes) {
                            if (cli.getCpf().equals(cpfCliente)) {
                                cli.setReservas(reserva);
                            }
                        }
                        return true;
                    }
                } else {
                    System.out.println("ESCOLHA O ASSENTO NÃO OCUPADO");
                    return false;
                }
            }
        }
        return false;
    }

    public void cancelarReserva(int index) {
        reservas.get(index).setAtivo(false);
    }

    public void removerReserva(int index) {
        reservas.remove(index);
    }

    public double estimarFaturamentoOtimista() {
        //Lembrete: if reserva.ativo == false: considera só 10% do valor da passagem.
        double faturamento = 0;
        for (Reserva reserva : reservas) {
            for (Voo voo : voos) {
                if (reserva.getVoo().getCodigoIdentificador() == voo.getCodigoIdentificador()) {
                    if (reserva.isAtivo()) {
                        if (reserva.isIsExecutiva()) {
                            faturamento += voo.getValorPassagemExecutiva();
                        } else {
                            faturamento += voo.getValorPassagemEconomica();
                        }
                    } else {
                        if (reserva.isIsExecutiva()) {
                            faturamento += voo.getValorPassagemExecutiva() / 10;
                        } else {
                            faturamento += voo.getValorPassagemEconomica() / 10;
                        }
                    }
                    // break;
                }
            }
        }
        return faturamento;
    }

    public double estimarFaturamentoPessimista() {
        double faturamento = 0;
        for (Reserva reserva : reservas) {
            for (Voo voo : voos) {
                if (reserva.getVoo().getCodigoIdentificador() == voo.getCodigoIdentificador()) {
                    if (reserva.isIsExecutiva()) {
                        faturamento += voo.getValorPassagemExecutiva() / 10;
                    } else {
                        faturamento += voo.getValorPassagemEconomica() / 10;
                    }
                }
                break;
            }
        }
        return faturamento;
    }

    public Destino getDestino() {
        Destino objDestino = new Destino();
        return objDestino;
    }

    public Voo getVoo() {
        Voo objVoo = new Voo();
        return objVoo;
    }

    public Aeronave getAeronave() {
        Aeronave objAeronave = new Aeronave();
        return objAeronave;
    }

    public Reserva getReserva(int codigoVoo, String cpfCliente) {
        Reserva objReserva = new Reserva();
        return objReserva;
    }

    public Cliente getCliente(String cpfCliente) {
        Cliente objCliente = new Cliente();
        return objCliente;
    }
}
